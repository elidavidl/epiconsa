"""
Convierte imágenes JPG o PNG a WebP optimizado.

Uso (desde la carpeta del proyecto):
    pip install pillow
    python tools/convertir_webp.py fotos-originales img

  - "fotos-originales" es la carpeta donde dejas tus fotos JPG o PNG.
  - "img" es la carpeta de salida (la que usa la página).

Cada foto queda en formato 4:5 (800 x 1000 px), que es el que usa el catálogo,
con calidad 80. El nombre se mantiene y solo cambia la extensión a .webp.
"""
import sys
from pathlib import Path

from PIL import Image, ImageOps

ANCHO, ALTO = 800, 1000   # proporción 4:5 del catálogo
CALIDAD = 80              # 75-85 es un buen equilibrio entre peso y nitidez

origen = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("fotos-originales")
destino = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("img")
destino.mkdir(exist_ok=True)

archivos = [f for f in origen.iterdir() if f.suffix.lower() in (".jpg", ".jpeg", ".png")]
if not archivos:
    sys.exit(f"No encontré imágenes JPG o PNG en '{origen}'.")

for f in sorted(archivos):
    with Image.open(f) as im:
        im = ImageOps.exif_transpose(im).convert("RGB")      # respeta la orientación de la cámara
        im = ImageOps.fit(im, (ANCHO, ALTO), Image.LANCZOS)  # recorta al centro en 4:5
        salida = destino / (f.stem + ".webp")
        im.save(salida, "WEBP", quality=CALIDAD, method=6)
        print(f"{f.name} -> {salida.name} ({salida.stat().st_size // 1024} KB)")

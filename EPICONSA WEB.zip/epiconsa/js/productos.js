/* ============================================================
   CATÁLOGO DE PRODUCTOS
   Para agregar un producto, copia un bloque { ... } y cambia sus datos.
   Para quitar uno, borra su bloque completo.

   id         texto único, sin espacios ni tildes
   nombre     nombre que se muestra
   categoria  las categorías nuevas aparecen solas en los filtros
   precio     número, sin símbolo (18 o 18.50)
   desc       frase corta debajo del nombre
   imagen     nombre del archivo dentro de la carpeta img/ (formato .webp)
   morado     true = también aparece en la sección "Octubre es morado"

   Los precios y las imágenes de este archivo son de ejemplo.
   ============================================================ */
const PRODUCTOS = [
  {
    id: "rosario-olivo",
    nombre: "Rosario de madera de olivo",
    categoria: "Rosarios",
    precio: 25,
    desc: "Cuentas de madera y cruz tallada.",
    imagen: "rosario-olivo.webp"
  },
  {
    id: "rosario-cristal-morado",
    nombre: "Rosario de cristal morado",
    categoria: "Rosarios",
    precio: 18,
    desc: "Cuentas de cristal con cadena plateada.",
    imagen: "rosario-morado.webp"
  },
  {
    id: "rosario-dorado",
    nombre: "Rosario dorado con estuche",
    categoria: "Rosarios",
    precio: 35,
    desc: "Ideal para primera comunión y regalo.",
    imagen: "rosario-dorado.webp"
  },
  {
    id: "virgen-carmen",
    nombre: "Virgen del Carmen, 30 cm",
    categoria: "Imágenes",
    precio: 55,
    desc: "Figura de resina pintada a mano.",
    imagen: "virgen-carmen.webp"
  },
  {
    id: "san-martin",
    nombre: "San Martín de Porres, 30 cm",
    categoria: "Imágenes",
    precio: 55,
    desc: "Figura de resina para altar o repisa.",
    imagen: "san-martin.webp"
  },
  {
    id: "sagrado-corazon",
    nombre: "Sagrado Corazón de Jesús, 40 cm",
    categoria: "Imágenes",
    precio: 78,
    desc: "Acabado mate con detalles dorados.",
    imagen: "sagrado-corazon.webp"
  },
  {
    id: "cuadro-milagros",
    nombre: "Cuadro Señor de los Milagros",
    categoria: "Imágenes",
    precio: 48,
    desc: "Marco dorado, 30 x 40 cm.",
    imagen: "cuadro-milagros.webp",
    morado: true
  },
  {
    id: "vela-7-dias",
    nombre: "Vela de 7 días en vaso",
    categoria: "Cirios y velas",
    precio: 12,
    desc: "Cera en vaso de vidrio con etiqueta.",
    imagen: "vela-7-dias.webp"
  },
  {
    id: "cirio-blanco",
    nombre: "Cirio blanco, 30 cm",
    categoria: "Cirios y velas",
    precio: 6,
    desc: "Para altar, misa y procesión.",
    imagen: "cirio-blanco.webp"
  },
  {
    id: "velon-morado",
    nombre: "Velón morado",
    categoria: "Cirios y velas",
    precio: 10,
    desc: "Cera gruesa de larga duración.",
    imagen: "velon-morado.webp",
    morado: true
  },
  {
    id: "biblia-tapa-dura",
    nombre: "Biblia católica, tapa dura",
    categoria: "Biblias y libros",
    precio: 45,
    desc: "Letra clara y cinta marcadora.",
    imagen: "biblia.webp"
  },
  {
    id: "devocionario",
    nombre: "Devocionario del hogar",
    categoria: "Biblias y libros",
    precio: 20,
    desc: "Oraciones diarias en formato de bolsillo.",
    imagen: "devocionario.webp"
  },
  {
    id: "escapulario-milagros",
    nombre: "Escapulario del Señor de los Milagros",
    categoria: "Escapularios y medallas",
    precio: 8,
    desc: "Tela morada con cordón.",
    imagen: "escapulario.webp",
    morado: true
  },
  {
    id: "medalla-san-benito",
    nombre: "Medalla de San Benito",
    categoria: "Escapularios y medallas",
    precio: 7,
    desc: "Metal dorado con cadena.",
    imagen: "medalla-benito.webp"
  },
  {
    id: "crucifijo-pared",
    nombre: "Crucifijo de pared, 25 cm",
    categoria: "Crucifijos",
    precio: 28,
    desc: "Madera barnizada con figura dorada.",
    imagen: "crucifijo-pared.webp"
  }
];

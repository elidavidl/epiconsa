/* ============================================================
   CONFIGURACIÓN DE EPICONSA
   Cambia aquí los datos del negocio. No hace falta tocar nada más.
   ============================================================ */
window.EPICONSA = {
  nombre: "EPICONSA",

  // Número de WhatsApp con código de país, solo dígitos (Perú = 51).
  // Ejemplo: 51987654321
  whatsapp: "51999999999",

  // Símbolo de moneda que se muestra antes del precio.
  moneda: "S/"
};

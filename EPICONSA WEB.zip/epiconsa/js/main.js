/* ============================================================
   LÓGICA DEL SITIO EPICONSA
   - Catálogo con filtros
   - Pedido (se guarda en el navegador) y envío por WhatsApp
   - Formulario de cotización por mayor
   ============================================================ */
(function () {
  "use strict";

  const CFG = window.EPICONSA;
  const $ = (sel, raiz = document) => raiz.querySelector(sel);
  const $$ = (sel, raiz = document) => Array.from(raiz.querySelectorAll(sel));

  const dinero = (n) => `${CFG.moneda} ${n.toFixed(2)}`;
  const esc = (t) =>
    String(t).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const porId = new Map(PRODUCTOS.map((p) => [p.id, p]));

  /* ---------- WhatsApp ---------- */
  function urlWhatsApp(mensaje) {
    return `https://wa.me/${CFG.whatsapp}?text=${encodeURIComponent(mensaje)}`;
  }

  $$("[data-wa]").forEach((a) => {
    a.href = urlWhatsApp(a.dataset.wa);
    a.target = "_blank";
    a.rel = "noopener";
  });

  /* ---------- Pedido (estado) ---------- */
  const CLAVE = "epiconsa-pedido";
  let pedido = cargarPedido();

  function cargarPedido() {
    try {
      const datos = JSON.parse(localStorage.getItem(CLAVE) || "{}");
      return datos && typeof datos === "object" ? datos : {};
    } catch (e) {
      return {};
    }
  }

  function guardarPedido() {
    try {
      localStorage.setItem(CLAVE, JSON.stringify(pedido));
    } catch (e) {
      /* si el navegador bloquea el almacenamiento, el pedido sigue en memoria */
    }
  }

  function lineas() {
    return Object.entries(pedido)
      .filter(([id, cant]) => porId.has(id) && cant > 0)
      .map(([id, cant]) => ({ p: porId.get(id), cant }));
  }

  const totalPedido = () => lineas().reduce((suma, l) => suma + l.p.precio * l.cant, 0);
  const cantidadTotal = () => lineas().reduce((suma, l) => suma + l.cant, 0);

  /* ---------- Aviso breve ---------- */
  let temporizadorAviso;
  function aviso(texto) {
    const el = $("#aviso");
    el.textContent = texto;
    el.classList.add("aviso--visible");
    clearTimeout(temporizadorAviso);
    temporizadorAviso = setTimeout(() => el.classList.remove("aviso--visible"), 2200);
  }

  /* ---------- Catálogo ---------- */
  function tarjetaProducto(p) {
    return `
      <article class="producto">
        <figure class="nicho">
          <img src="img/${esc(p.imagen)}" width="800" height="1000" loading="lazy" alt="${esc(p.nombre)}">
        </figure>
        <h3 class="producto__nombre">${esc(p.nombre)}</h3>
        <p class="producto__desc">${esc(p.desc)}</p>
        <div class="producto__pie">
          <span class="precio">${dinero(p.precio)}</span>
          <button class="btn btn--mini" type="button" data-agregar="${esc(p.id)}">Agregar al pedido</button>
        </div>
      </article>`;
  }

  const categorias = ["Todo", ...new Set(PRODUCTOS.map((p) => p.categoria))];
  let filtroActual = "Todo";

  function crearFiltros() {
    const contenedor = $("#filtros");
    categorias.forEach((cat) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "chip";
      b.textContent = cat;
      b.setAttribute("aria-pressed", String(cat === filtroActual));
      b.addEventListener("click", () => {
        filtroActual = cat;
        $$(".chip", contenedor).forEach((c) => c.setAttribute("aria-pressed", String(c === b)));
        pintarCatalogo();
      });
      contenedor.append(b);
    });
  }

  function pintarCatalogo() {
    const lista = PRODUCTOS.filter((p) => filtroActual === "Todo" || p.categoria === filtroActual);
    $("#productos").innerHTML = lista.map(tarjetaProducto).join("");
    $("#conteo").textContent =
      lista.length === 1 ? "1 producto" : `${lista.length} productos`;
  }

  function pintarMorado() {
    const lista = PRODUCTOS.filter((p) => p.morado);
    $("#morado-lista").innerHTML = lista.map(tarjetaProducto).join("");
  }

  /* ---------- Pedido (interfaz) ---------- */
  function pintarPedido() {
    const items = lineas();
    const n = cantidadTotal();

    $("#pedido-n").textContent = n;
    $("#pedido-total").textContent = dinero(totalPedido());
    $("#pedido-vacio").hidden = items.length > 0;
    $("#enviar-pedido").disabled = items.length === 0;
    $("#vaciar-pedido").hidden = items.length === 0;

    $("#pedido-lista").innerHTML = items
      .map(
        ({ p, cant }) => `
        <li class="linea">
          <img class="linea__img" src="img/${esc(p.imagen)}" width="56" height="70" alt="">
          <div class="linea__datos">
            <p class="linea__nombre">${esc(p.nombre)}</p>
            <p class="linea__precio">${dinero(p.precio * cant)}</p>
            <div class="cantidad" role="group" aria-label="Cantidad de ${esc(p.nombre)}">
              <button type="button" data-menos="${esc(p.id)}" aria-label="Quitar una unidad">&minus;</button>
              <span>${cant}</span>
              <button type="button" data-mas="${esc(p.id)}" aria-label="Agregar una unidad">+</button>
            </div>
          </div>
        </li>`
      )
      .join("");
  }

  function cambiarCantidad(id, delta) {
    const nueva = (pedido[id] || 0) + delta;
    if (nueva <= 0) delete pedido[id];
    else pedido[id] = nueva;
    guardarPedido();
    pintarPedido();
  }

  document.addEventListener("click", (e) => {
    const agregar = e.target.closest("[data-agregar]");
    if (agregar) {
      const p = porId.get(agregar.dataset.agregar);
      cambiarCantidad(p.id, 1);
      aviso(`Agregado al pedido: ${p.nombre}`);
      return;
    }
    const mas = e.target.closest("[data-mas]");
    if (mas) return cambiarCantidad(mas.dataset.mas, 1);
    const menos = e.target.closest("[data-menos]");
    if (menos) return cambiarCantidad(menos.dataset.menos, -1);
  });

  const panel = $("#pedido");
  $("#abrir-pedido").addEventListener("click", () => panel.showModal());
  panel.addEventListener("click", (e) => {
    if (e.target === panel) panel.close(); // clic en el fondo oscuro
  });

  $("#vaciar-pedido").addEventListener("click", () => {
    pedido = {};
    guardarPedido();
    pintarPedido();
  });

  $("#enviar-pedido").addEventListener("click", () => {
    const items = lineas();
    if (!items.length) return;
    const detalle = items
      .map(({ p, cant }) => `- ${cant} x ${p.nombre} (${dinero(p.precio * cant)})`)
      .join("\n");
    const mensaje = `Hola ${CFG.nombre}, quiero hacer este pedido:\n${detalle}\nTotal: ${dinero(totalPedido())}`;
    window.open(urlWhatsApp(mensaje), "_blank", "noopener");
  });

  /* ---------- Formulario de cotización ---------- */
  $("#form-cotizacion").addEventListener("submit", (e) => {
    e.preventDefault();
    const f = e.target;
    const nombre = f.nombre.value.trim();
    const institucion = f.institucion.value.trim();
    const detalle = f.detalle.value.trim();
    const error = $("#form-error");

    if (!nombre || !detalle) {
      error.textContent = "Escribe tu nombre y lo que necesitas para poder enviar la cotización.";
      error.hidden = false;
      (nombre ? f.detalle : f.nombre).focus();
      return;
    }
    error.hidden = true;

    const quien = institucion ? `${nombre}, de ${institucion}` : nombre;
    const mensaje = `Hola ${CFG.nombre}, soy ${quien}.\nQuisiera una cotización por mayor:\n${detalle}`;
    window.open(urlWhatsApp(mensaje), "_blank", "noopener");
  });

  /* ---------- Inicio ---------- */
  $("#anio").textContent = new Date().getFullYear();
  crearFiltros();
  pintarCatalogo();
  pintarMorado();
  pintarPedido();
})();
